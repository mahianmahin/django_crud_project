from django.shortcuts import render
from .forms import StudentRegistration
from .models import User
from django.http import HttpResponseRedirect

# Create your views here.
def add_show(request):
    if request.method == 'POST':
        form = StudentRegistration(request.POST)
        if form.is_valid():

            name_data = form.cleaned_data['name']
            email_data = form.cleaned_data['email']
            password_data = form.cleaned_data['password']

            reg = User(name = name_data, email = email_data, password = password_data )
            reg.save() 
            form = StudentRegistration()

    else:
        form = StudentRegistration()
    
    # students = User.objects.all()

    return render(request, 'enroll/addandshow.html', {'form' : form, 'stu' : User.objects.all()})

def update_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(request.POST, instance = pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(instance=pi)

    return render(request, 'enroll/updatestudent.html', {'form' : fm})


def delete_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')
